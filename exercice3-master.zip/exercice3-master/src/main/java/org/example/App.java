package org.example;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.S3Exception;

public class App {
    public static void main(String[] args) {

        System.out.println("Application starts");

        try (S3Client s3 = S3Client.builder().build()) {

            s3.listBuckets().buckets().forEach(b ->
                    System.out.println("Bucket détecté : " + b.name())
            );

        } catch (S3Exception e) {
            System.err.println("Erreur AWS : " + e.awsErrorDetails().errorMessage());
        }

        System.out.println("Application ends");
    }
}
